# -*- coding: utf-8 -*-
"""
Created on Wed May  1 12:41:04 2019

@author: Phero-PC
"""

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
matplotlib.style.use('ggplot')

df=pd.read_csv("E:/Semester 8/DSA/files/wheat.csv")
print(df.columns)
my_dataframe=df[['area','perimeter']]
my_dataframe.plot.hist(alpha=0.75)
plt.title("16CS34")
plt.show()
my_dataframe=df[['groove','asymmetry']]
my_dataframe.plot.hist(alpha=0.75)
plt.title("16CS34")
plt.show()

